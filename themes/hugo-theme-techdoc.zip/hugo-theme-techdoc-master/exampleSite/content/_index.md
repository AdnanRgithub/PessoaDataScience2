---
date: 2017-10-17T15:26:15Z
lastmod: 2018-12-05T15:26:15Z
---

# Hugo Techdoc Theme

## The Techdoc is a Hugo Theme for technical documentation.

## Features

* Modern, Simple layout
* Responsive web design
* Edit link to documentation repository
* Custom Shortcodes
* Analytics with Google Analytics, Google Tag Manager
