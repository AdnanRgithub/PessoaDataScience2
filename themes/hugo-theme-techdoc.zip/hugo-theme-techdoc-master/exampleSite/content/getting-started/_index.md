---
title: "Getting Started"
date: 2017-10-17T15:26:15Z
lastmod: 2018-12-05T15:26:15Z
draft: false
weight: 9
---

## [Installation](./installation)

Download Hugo theme, configure, preview site ...

## [Configuration](./configuration)

You may specify options in config.toml (or config.yaml/config.json) of your site to make use of this theme's features.
